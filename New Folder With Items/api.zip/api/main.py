from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from api.inference import SkinModel, SkinTypeModel
from PIL import Image
from pydantic import BaseModel
from api.recommender import recommend_routine
from typing import Optional, List
from api.quality_gate import assess_image_quality, QualityConfig
from api.safety_filter import filter_routine_for_user
from api.outcome_risk import compute_outcome_and_risk
from api.explainability import gradcam_overlay_base64
from api.face_crop import crop_face
from datetime import datetime



import os
import io
import hashlib
import json

import mysql.connector
from mysql.connector import Error, IntegrityError

app = FastAPI()

# === MySQL CONFIG ===
MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_USER = "root"              # <-- change if needed
MYSQL_PASSWORD = "kayra0505"     # <-- put your MySQL password here
MYSQL_DB = "aurai"               # the DB you created in Workbench




def get_connection():
    """Create a new MySQL connection."""
    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
    )


def init_db():
    """Create tables if they do not exist."""
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        # Users table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password_hash VARCHAR(64) NOT NULL
            )
            """
        )

        # Scans table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                results_json TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )

        conn.commit()
        cur.close()
    except Error as e:
        print("Error while initializing DB:", e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def hash_password(password: str) -> str:
    # For a uni project this is fine; in production use bcrypt/argon2
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    address: Optional[str] = None
    allergies: Optional[str] = None



class LoginRequest(BaseModel):
    email: str
    password: str


class ScanCreate(BaseModel):
    user_id: int
    results: dict

class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    age: Optional[int] = None
    address: Optional[str] = None
    allergies: Optional[str] = None

UPLOAD_DIR = "uploads"

def save_upload_image(contents: bytes) -> str:
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    h = hashlib.sha256(contents).hexdigest()[:16]
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"scan_{ts}_{h}.jpg"
    path = os.path.join(UPLOAD_DIR, filename)
    with open(path, "wb") as f:
        f.write(contents)
    return path




@app.on_event("startup")
def on_startup():
    init_db()


# Allow all origins for now (you can restrict later)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Load models ===
# NOTE: these relative paths assume you run uvicorn from PROJECT ROOT.
# If you run from inside /api folder, you may need to adjust paths.

MODEL_PATH = "models/best_multilabel.pt"
THRESHOLDS_PATH = "models/per_class_thresholds.json"

SKIN_TYPE_MODEL_PATH = "models/skin_type_resnet18.pt"

# Multilabel skin condition model (acne, redness, etc.)
model = SkinModel(
    model_path=MODEL_PATH,
    thresholds_path=THRESHOLDS_PATH,
)

# NEW: skin type model (normal/combination/oily/dry/sensitive)
skin_type_model = SkinTypeModel(
    checkpoint_path=SKIN_TYPE_MODEL_PATH
)


@app.get("/")
def root():
    return {"message": "Skin condition API is running."}


@app.post("/predict")
async def predict(
    file: UploadFile = File(...),
    user_id: int | None = Form(None),
    ):
    contents = await file.read()
    image_path = save_upload_image(contents)


    try:
        image = Image.open(io.BytesIO(contents)).convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid image")

    # === PHASE 1: Image Quality Gate (blocks pipeline early) ===
    quality = assess_image_quality(image, QualityConfig())
    if not quality["passed"]:
        # Return 200 so frontend can show a friendly retake prompt
        return {
            "ok": False,
            "quality": quality,
            "message": "Image quality too low. Please retake in better lighting and focus."
        }

    # 1) predict skin type
    skin_type_out = skin_type_model.predict(image)
    skin_type = skin_type_out["skin_type"]

    # 2) predict skin concerns
    results = model.predict(image)

    # 3) recommend routine based on concerns + skin type
    mapped_skin_type = skin_type
    if mapped_skin_type in ["dry", "sensitive"]:
        mapped_skin_type = "normal"

    routine_raw = recommend_routine(results, skin_type=mapped_skin_type)

    # === PHASE 2: Safety & Suitability Filter (allergies etc.) ===
    allergies_text = None
    if user_id is not None:
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT allergies FROM users WHERE id=%s", (user_id,))
            row = cur.fetchone()
            cur.close()
            if conn.is_connected():
                conn.close()
            if row:
                allergies_text = row[0]
        except Exception as e:
            print("Failed to fetch allergies for safety filter:", e)

    routine_filtered, safety = filter_routine_for_user(routine_raw, allergies_text)
    phase3 = compute_outcome_and_risk(results, skin_type_out, routine_filtered)


    return {
    "ok": True,
    "quality": quality,
    "results": results,
    "skin_type": skin_type_out,
    "routine_raw": routine_raw,
    "routine": routine_filtered,
    "safety": safety,
    **phase3,   # adds "outcome" and "risk",
    "image_path": image_path,
    }




# === Auth endpoints using MySQL ===

@app.post("/register")
def register(user: RegisterRequest):
    try:
        conn = get_connection()
        cur = conn.cursor()

        sql = """
        INSERT INTO users (name, email, password_hash, address, allergies)
        VALUES (%s, %s, %s, %s, %s)
        """
        cur.execute(
            sql,
            (
                user.name.strip(),
                user.email.strip().lower(),
                hash_password(user.password),
                user.address,
                user.allergies,
            ),
        )

        conn.commit()
        user_id = cur.lastrowid

        cur.close()
        conn.close()

        return {
            "id": user_id,
            "name": user.name.strip(),
            "email": user.email.strip().lower(),
        }


    except IntegrityError:
        if conn is not None and conn.is_connected():
            conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")

    except Error as e:
        print("MySQL error in /register:", e)
        if conn is not None and conn.is_connected():
            conn.close()
        raise HTTPException(status_code=500, detail="Database error")


@app.post("/login")
def login(data: LoginRequest):
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        sql = """
        SELECT id, name, email, password_hash
        FROM users
        WHERE email = %s
        """
        cur.execute(sql, (data.email.strip().lower(),))
        row = cur.fetchone()

        cur.close()
        if conn.is_connected():
            conn.close()

        if row is None:
            raise HTTPException(status_code=400, detail="Invalid email or password")

        user_id, name, email, pw_hash = row

        if pw_hash != hash_password(data.password):
            raise HTTPException(status_code=400, detail="Invalid email or password")

        return {"id": user_id, "name": name, "email": email}

    except Error as e:
        print("MySQL error in /login:", e)
        if conn is not None and conn.is_connected():
            conn.close()
        raise HTTPException(status_code=500, detail="Database error")


@app.post("/scans")
def save_scan(data: ScanCreate):
    """Save a scan result for a user."""
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        sql = """
        INSERT INTO scans (user_id, results_json)
        VALUES (%s, %s)
        """
        cur.execute(sql, (data.user_id, json.dumps(data.results)))
        conn.commit()
        scan_id = cur.lastrowid

        cur.close()
        if conn.is_connected():
            conn.close()

        return {"id": scan_id}

    except Error as e:
        print("MySQL error in /scans (POST):", e)
        if conn is not None and conn.is_connected():
            conn.close()
        raise HTTPException(status_code=500, detail="Database error")


@app.get("/scans")
def list_scans(user_id: int, limit: int = 10):
    """Return recent scans for a user (newest first)."""
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        sql = """
        SELECT id, created_at, results_json
        FROM scans
        WHERE user_id = %s
        ORDER BY created_at DESC
        LIMIT %s
        """
        cur.execute(sql, (user_id, limit))
        rows = cur.fetchall()

        cur.close()
        if conn.is_connected():
            conn.close()

        scans = []
        for row in rows:
            scan_id, created_at, results_json = row
            try:
                results = json.loads(results_json)
            except Exception:
                results = {}
            scans.append(
                {
                    "id": scan_id,
                    "created_at": created_at,
                    "results": results,
                }
            )

        return {"items": scans}

    except Error as e:
        print("MySQL error in /scans (GET):", e)
        if conn is not None and conn.is_connected():
            conn.close()
        raise HTTPException(status_code=500, detail="Database error")
    
@app.get("/explain")
def explain(scan_id: int, target: str):
    """
    target: acne | redness | blackheads | bags | hyperpigmentation
    """
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT results_json FROM scans WHERE id=%s", (scan_id,))
        row = cur.fetchone()
        cur.close()
        if conn.is_connected():
            conn.close()

        if not row:
            raise HTTPException(status_code=404, detail="Scan not found")

        results_obj = json.loads(row[0] or "{}")

        # We stored image_path inside results_json (next step)
        image_path = results_obj.get("image_path")
        if not image_path or not os.path.exists(image_path):
            raise HTTPException(status_code=404, detail="Scan image not found on server")

        img = Image.open(image_path).convert("RGB")
        out = gradcam_overlay_base64(model, img, target_label=target)
        return {"ok": True, **out}

    except HTTPException:
        raise
    except Exception as e:
        print("Error in /explain:", e)
        raise HTTPException(status_code=500, detail="Explainability error")
    finally:
        if conn is not None and getattr(conn, "is_connected", lambda: False)():
            conn.close()


@app.get("/me")
def get_me(user_id: int):
    try:
        conn = get_connection()
        cur = conn.cursor()

        sql = """
        SELECT id, name, email, phone, age, address, allergies
        FROM users
        WHERE id = %s
        """
        cur.execute(sql, (user_id,))
        row = cur.fetchone()

        cur.close()
        if conn.is_connected():
            conn.close()

        if row is None:
            raise HTTPException(status_code=404, detail="User not found")

        uid, name, email, phone, age, address, allergies = row
        return {
            "id": uid,
            "name": name,
            "email": email,
            "phone": phone,
            "age": age,
            "address": address,
            "allergies": allergies,
        }
    except Error as e:
        print("MySQL error in /me (GET):", e)
        raise HTTPException(status_code=500, detail="Database error")


@app.put("/me")
def update_me(user_id: int, data: ProfileUpdate):
    try:
        conn = get_connection()
        cur = conn.cursor()

        # Load existing so we can update only provided fields
        cur.execute(
            "SELECT name, email, phone, age, address, allergies FROM users WHERE id=%s",
            (user_id,),
        )
        row = cur.fetchone()
        if row is None:
            cur.close()
            if conn.is_connected():
                conn.close()
            raise HTTPException(status_code=404, detail="User not found")

        current = {
            "name": row[0],
            "email": row[1],
            "phone": row[2],
            "age": row[3],
            "address": row[4],
            "allergies": row[5],
        }

        updated = {
            "name": current["name"],
            "email": current["email"],
            "phone": data.phone if data.phone is not None else current["phone"],
            "age": current["age"], 
            "address": data.address if data.address is not None else current["address"],
            "allergies": data.allergies if data.allergies is not None else current["allergies"],
        }

        # email uniqueness check if changed
        if updated["email"] != current["email"]:
            cur.execute("SELECT id FROM users WHERE email=%s AND id<>%s", (updated["email"], user_id))
            if cur.fetchone() is not None:
                cur.close()
                if conn.is_connected():
                    conn.close()
                raise HTTPException(status_code=400, detail="Email already in use")

        sql = """
        UPDATE users
        SET name=%s, email=%s, phone=%s, age=%s, address=%s, allergies=%s
        WHERE id=%s
        """
        cur.execute(
            sql,
            (
                updated["name"],
                updated["email"],
                updated["phone"],
                updated["age"],
                updated["address"],
                updated["allergies"],
                user_id,
            ),
        )
        conn.commit()

        cur.close()
        if conn.is_connected():
            conn.close()

        return {"ok": True, "user": {"id": user_id, **updated}}
    except IntegrityError:
        raise HTTPException(status_code=400, detail="Email already in use")
    except Error as e:
        print("MySQL error in /me (PUT):", e)
        raise HTTPException(status_code=500, detail="Database error")
