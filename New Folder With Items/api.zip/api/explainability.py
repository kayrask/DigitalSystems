# api/explainability.py
from __future__ import annotations

from typing import Dict, Any
from PIL import Image
import numpy as np
import torch
import torch.nn.functional as F
import base64
import io

LABELS = ["acne", "bags", "blackheads", "hyperpigmentation", "redness"]


def _to_numpy_rgb(img: Image.Image) -> np.ndarray:
    arr = np.asarray(img.convert("RGB")).astype(np.float32) / 255.0
    return arr


def _overlay_red_heatmap(img_rgb: np.ndarray, cam: np.ndarray, strength: float = 0.55) -> Image.Image:
    """
    img_rgb: [H,W,3] float 0..1
    cam: [H,W] float 0..1
    """
    cam = np.clip(cam, 0, 1)
    # red heatmap: (1,0,0) with alpha=cam
    alpha = (cam * strength)[..., None]  # [H,W,1]

    red = np.zeros_like(img_rgb)
    red[..., 0] = 1.0

    blended = img_rgb * (1 - alpha) + red * alpha
    blended = np.clip(blended * 255.0, 0, 255).astype(np.uint8)
    return Image.fromarray(blended)


def gradcam_overlay_base64(
    skin_model,  # your SkinModel instance (the multilabel one)
    image: Image.Image,
    target_label: str,
) -> Dict[str, Any]:
    """
    Returns {"target":..., "overlay_png_base64":..., "cam_minmax":[...]}
    Works with resnet18-like model inside skin_model.model and skin_model.transform.
    """
    if target_label not in LABELS:
        raise ValueError(f"target_label must be one of {LABELS}")

    device = skin_model.device
    model = skin_model.model
    model.eval()

    # Pick a target layer: for resnet18, layer4 is the last conv block
    target_layer = model.layer4

    activations = []
    gradients = []

    def fwd_hook(_, __, out):
        activations.append(out)

    def bwd_hook(_, grad_in, grad_out):
        # grad_out[0] is gradient wrt layer output
        gradients.append(grad_out[0])

    h1 = target_layer.register_forward_hook(fwd_hook)
    h2 = target_layer.register_full_backward_hook(bwd_hook)

    try:
        x = skin_model.transform(image).unsqueeze(0).to(device)  # [1,3,224,224]
        x.requires_grad_(True)

        logits = model(x)  # [1,5]
        idx = LABELS.index(target_label)

        # multilabel: use the logit for the target class
        score = logits[0, idx]
        model.zero_grad(set_to_none=True)
        score.backward()

        act = activations[-1]      # [1,C,h,w]
        grad = gradients[-1]       # [1,C,h,w]

        # Global-average-pool gradients -> weights
        w = grad.mean(dim=(2, 3), keepdim=True)  # [1,C,1,1]
        cam = (w * act).sum(dim=1, keepdim=True)  # [1,1,h,w]
        cam = F.relu(cam)

        # Normalize cam to 0..1
        cam = cam[0, 0]
        cam = cam - cam.min()
        cam = cam / (cam.max() + 1e-8)

        # Upsample cam to original image size
        H, W = image.size[1], image.size[0]
        cam_up = F.interpolate(cam[None, None, ...], size=(H, W), mode="bilinear", align_corners=False)[0, 0]
        cam_np = cam_up.detach().cpu().numpy()

        img_np = _to_numpy_rgb(image)
        overlay = _overlay_red_heatmap(img_np, cam_np, strength=0.55)

        # encode as base64 PNG
        buf = io.BytesIO()
        overlay.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        return {
            "target": target_label,
            "overlay_png_base64": b64,
            "cam_minmax": [float(cam_np.min()), float(cam_np.max())],
        }

    finally:
        h1.remove()
        h2.remove()
