# api/inference.py
import torch
import json
import os
from PIL import Image
from torchvision import models, transforms
import torch.nn as nn

LABELS = ["acne", "bags", "blackheads", "hyperpigmentation", "redness"]

class SkinModel:
    def __init__(self, model_path, thresholds_path=None, device=None):
        self.device = device or ("mps" if torch.backends.mps.is_available() else "cpu")

        # Model definition (same as training)
        self.model = self._build_model(num_classes=len(LABELS))
        ckpt = torch.load(model_path, map_location=self.device)

        if "model" in ckpt:
            self.model.load_state_dict(ckpt["model"])
        elif "state_dict" in ckpt:
            self.model.load_state_dict(ckpt["state_dict"])
        else:
            raise ValueError("Checkpoint must contain 'model' or 'state_dict'.")

        self.model.to(self.device).eval()

        # Load thresholds
        if thresholds_path and os.path.exists(thresholds_path):
            with open(thresholds_path, "r") as f:
                self.thresholds = json.load(f)
        else:
            self.thresholds = {lbl: 0.5 for lbl in LABELS}

        # transforms (same as eval)
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])

    def _build_model(self, num_classes):
        import torchvision.models as models
        m = models.resnet18(weights=None)
        in_f = m.fc.in_features
        m.fc = nn.Linear(in_f, num_classes)
        return m

    def predict(self, image: Image.Image):
        img = self.transform(image).unsqueeze(0).to(self.device)

        with torch.no_grad():
            logits = self.model(img)
            probs = torch.sigmoid(logits).cpu().numpy()[0]

        result = {}
        for i, label in enumerate(LABELS):
            result[label] = {
                "probability": float(probs[i]),
                "prediction": int(probs[i] >= self.thresholds[label])
            }

        return result

class SkinTypeModel:
    def __init__(self, checkpoint_path: str):
        self.device = torch.device(
            "mps" if torch.backends.mps.is_available()
            else "cuda" if torch.cuda.is_available()
            else "cpu"
        )

        ckpt = torch.load(checkpoint_path, map_location=self.device)
        self.classes = ckpt.get(
            "classes",
            ["combination", "dry", "normal", "oily", "sensitive"],
        )

        self.model = models.resnet18(weights=None)
        self.model.fc = torch.nn.Linear(
            self.model.fc.in_features, len(self.classes)
        )
        self.model.load_state_dict(ckpt["model"])
        self.model.to(self.device)
        self.model.eval()

        self.tf = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

    def predict(self, pil_image):
        x = self.tf(pil_image).unsqueeze(0).to(self.device)
        with torch.no_grad():
            logits = self.model(x)
            probs = torch.softmax(logits, dim=1)[0].cpu().numpy()

        idx = int(probs.argmax())
        return {
            "skin_type": self.classes[idx],
            "confidence": float(probs[idx]),
            "probs": {
                self.classes[i]: float(probs[i])
                for i in range(len(self.classes))
            },
        }
